module.exports = {
  BOT_TOKEN: "7722248068:AAE8YjQfxVilJA8lw5eKiSi3RfNjEDb_Ous", // Token bot Telegram
  OWNER_ID: "7188042729", // ID pemilik bot
  allowedGroupIds: [-1002401306074, -1002361556670, -1002386380830, -1002415460020, -4514397992], // ID grup yang diizinkan
};